<?php
/**
 * Gabarit des vues
 *
 * PHP Version 8
 *
 */
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta charset="UTF-8">
        <title>Intranet du Laboratoire Galaxy-Swiss Bourdin</title>
        <meta name="description" content="">
        <meta name="author" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="<?= ASSETS; ?>styles/bootstrap/bootstrap.css" rel="stylesheet">
        <link href="<?= ASSETS; ?>styles/style.css" rel="stylesheet">
    </head>
    <body>
        <div class="container">
            <?php
            if(isset($estConnecte)){
                $uc = filter_input(INPUT_GET, 'uc', FILTER_SANITIZE_SPECIAL_CHARS);
                if ($estConnecte) {
                    if($_SESSION['statut'] == 'V') {
                        //NAV VISITEUR
                    ?>
                        <div class="header">
                            <div class="row vertical-align">
                                <div class="col-md-4">
                                    <h1>
                                        <img src="<?= ASSETS; ?>images/logo.jpg" class="img-responsive"
                                            alt="Laboratoire Galaxy-Swiss Bourdin"
                                            title="Laboratoire Galaxy-Swiss Bourdin">
                                    </h1>
                                </div>
                                <div class="col-md-8">
                                    <ul class="nav nav-pills pull-right" role="tablist">
                                        <li <?php if (!$uc || $uc == 'accueil') { ?>class="active" <?php } ?>>
                                            <a href="<?= HOST; ?>accueil">
                                                <span class="glyphicon glyphicon-home"></span>
                                                Accueil
                                            </a>
                                        </li>
                                        <li <?php if ($uc == 'gererFrais') { ?>class="active"<?php } ?>>
                                            <a href="<?= HOST; ?>gererFrais/action/saisirFrais">
                                                <span class="glyphicon glyphicon-pencil"></span>
                                                Renseigner la fiche de frais
                                            </a>
                                        </li>
                                        <li <?php if ($uc == 'etatFrais') { ?>class="active"<?php } ?>>
                                            <a href="<?= HOST; ?>etatFrais/action/selectionnerMois">
                                                <span class="glyphicon glyphicon-list-alt"></span>
                                                Afficher mes fiches de frais
                                            </a>
                                        </li>
                                        <li
                                        <?php if ($uc == 'deconnexion') { ?>class="active"<?php } ?>>
                                            <a href="<?= HOST; ?>deconnexion">
                                                <span class="glyphicon glyphicon-log-out"></span>
                                                Déconnexion
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="waveV">
                            <img src="<?= ASSETS; ?>images/vagueV.jpg"  style="position: fixed;bottom: 0;left: 0;width: 100%;height: auto;z-index: -1;">
                        </div>
                <?php
                } else {
                        //NAV COMPTABLE
                        ?>
                        <div class="header">
                        <div class="row vertical-align">
                            <div class="col-md-4">
                                <h1>
                                    <img src="<?= ASSETS; ?>images/logo.jpg" class="img-responsive"
                                        alt="Laboratoire Galaxy-Swiss Bourdin"
                                        title="Laboratoire Galaxy-Swiss Bourdin">
                                </h1>
                            </div>
                            <div class="col-md-8">
                                <ul class="nav nav-pills pull-right" role="tablist">
                                    <li <?php if (!$uc || $uc == 'accueilC') { ?>class="active" <?php } ?>>
                                        <a href="<?= HOST; ?>accueilC">
                                            <span class="glyphicon glyphicon-home"></span>
                                            Accueil
                                        </a>
                                    </li>
                                    <li <?php if ($uc == 'validerFrais') { ?>class="active"<?php } ?>>
                                        <a href="<?= HOST; ?>validerFrais/action/selectionnerVisiteur">
                                            <span class="glyphicon glyphicon-pencil"></span>
                                            Valider fiche de frais
                                        </a>
                                    </li>
                                    <li <?php if ($uc == 'suivreFrais') { ?>class="active"<?php } ?>>
                                        <a href="<?= HOST; ?>suivreFrais/action/selectionnerVisiteur">
                                            <span class="glyphicon glyphicon-list-alt"></span>
                                            Suivre paiement fiche de frais
                                        </a>
                                    </li>
                                    <li
                                    <?php if ($uc == 'deconnexion') { ?>class="active"<?php } ?>>
                                        <a href="<?= HOST; ?>deconnexion">
                                            <span class="glyphicon glyphicon-log-out"></span>
                                            Déconnexion
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="wave">
                        <img src="<?= ASSETS; ?>images/vague.jpg"  style="position: fixed;bottom: 0;left: 0;width: 100%;height: auto;z-index: -1;">
                    </div>
                    <?php
                        } //Nav Comptable
                    }//Nav Visiteur
                }
            else {   //Personne n'est connecté
            ?>
            <h1>
                <img src="<?= ASSETS; ?>images/logo.jpg"
                        class="img-responsive center-block"
                        alt="Laboratoire Galaxy-Swiss Bourdin"
                        title="Laboratoire Galaxy-Swiss Bourdin">
            </h1>
            <?php
            }

            echo $contentPage; ?>
        </div>
    </body>
</html>