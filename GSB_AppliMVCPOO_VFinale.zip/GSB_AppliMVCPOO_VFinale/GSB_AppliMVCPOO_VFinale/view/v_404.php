<?php
/**
 * Vue Accueil
 *
 * PHP Version 8
 *
 * @category  AP
 * @package   GSB
 * @link      Contexte « Laboratoire GSB »
 */
?>
<div id="accueil">
    <h2>
        Gestion des frais<small> 
    </h2>
</div>
<div class="row text-center">
    <h2>La page demandée n'existe pas !</h2>

</div>
